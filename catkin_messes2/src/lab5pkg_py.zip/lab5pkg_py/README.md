### Terminal 1  
#### $ cd ~/catkin_NETID  
#### $ catkin_make  
#### $ source devel/setup.bash  
#### $ roslaunch ur3_driver ur3_vision_driver.launch  

### Terminal 2  
#### $ source devel/setup.bash  
#### $ rosrun lab5pkg_py lab5_exec.py
