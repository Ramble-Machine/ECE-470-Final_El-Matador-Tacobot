#!/usr/bin/env python

import cv2
import numpy as np
import time
from  math import *
# ========================= Student's code starts here =========================

# Params for camera calibration
theta = 0.006747589115388215
beta = 750
Or = 240
Oc = 320
x_w = 0.2
y_w = 0.0

col = 230.9254760742187
row = 194.905258178
#264.8562316894531, second: 197.4044189453125

x_c = (row-Or)/beta
y_c = (col-Oc)/beta

Rot = np.array([[np.cos(theta), -np.sin(theta)],[np.sin(theta),np.cos(theta)]])

X_w = np.array([[x_w],[y_w]])
X_c = np.array([[x_c], [y_c]])



T =X_w -Rot@X_c

# Function that converts image coord to world coord
def IMG2W(col, row):
    global T
    global Rot
    Coord = Rot@ np.array([[(row-Or)/beta], [(col-Oc)/beta]]) + T
    return [Coord[0]*1000, Coord[1]*1000, 39, 0]

# ========================= Student's code ends here ===========================

def blob_search(image_raw, color):

    # Setup SimpleBlobDetector parameters.
    params = cv2.SimpleBlobDetector_Params()

    # ========================= Student's code starts here =========================

    # Filter by Color
    params.filterByColor = False

    # Filter by Area.
    params.filterByArea = False

    # Filter by Circularity
    params.filterByCircularity = False

    # Filter by Inerita
    params.filterByInertia = False

    # Filter by Convexity
    params.filterByConvexity = False

    # ========================= Student's code ends here ===========================

    # Create a detector with the parameters
    detector = cv2.SimpleBlobDetector_create(params)

    # Convert the image into the HSV color space
    hsv_image = cv2.cvtColor(image_raw, cv2.COLOR_BGR2HSV)

    # ========================= Student's code starts here =========================
    if (color=="orange"):
        upper = (18, 255, 255)     # orang uup
        lower = (5, 60, 165)   # orang luuu
    elif (color== "babyblue" ):
        upper = (150, 255, 255)     # bb uup
        lower = (70, 60, 70)   # bb luuu    
    elif (color== "green"):
        upper = (65, 200, 255)     # gren uup
        lower = (50, 80, 80)   # gren luuu    
        
    # Define a mask using the lower and upper bounds of the target color
    mask_image = cv2.inRange(hsv_image, lower, upper)

    # ========================= Student's code ends here ===========================

    keypoints = detector.detect(mask_image)

    # Find blob centers in the image coordinates
    blob_image_center = []
    num_blobs = len(keypoints)
    for i in range(num_blobs):
        blob_image_center.append((keypoints[i].pt[0],keypoints[i].pt[1]))
    
        
    # ========================= Student's code starts here =========================
    
    # Draw the keypoints on the detected block
    im_with_keypoints = cv2.drawKeypoints(image_raw, keypoints, lower, upper)

    # ========================= Student's code ends here ===========================

    xw_yw = []

    if(num_blobs == 0):
        print("No block found!")
    else:
        # Convert image coordinates to global world coordinate using IM2W() function
        for i in range(num_blobs):
            xw_yw.append(IMG2W(blob_image_center[i][0], blob_image_center[i][1]))


    cv2.namedWindow("Camera View")
    cv2.imshow("Camera View", image_raw)
    cv2.namedWindow("Mask View")
    cv2.imshow("Mask View", mask_image)
    cv2.namedWindow("Keypoint View")
    cv2.imshow("Keypoint View", im_with_keypoints)

    cv2.waitKey(2)
    return xw_yw